
function Point(p_x, p_y, p_corner)
{
	this.x = (p_x) ? Number(p_x) : 0;
	this.y = (p_y) ? Number(p_y) : 0;
	this.corner = (p_corner) ? Number(p_corner) : 0;
}
